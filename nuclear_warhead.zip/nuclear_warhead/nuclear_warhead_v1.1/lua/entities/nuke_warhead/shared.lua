ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Retrosoul Nuclear Warhead"
ENT.Author = "Retrosoul"
ENT.Spawnable = false
ENT.AdminOnly = true
