include("shared.lua")

surface.CreateFont("RetrosoulNuke_Big", {font = "Trebuchet24", size = 36, weight = 900})
surface.CreateFont("RetrosoulNuke_Small", {font = "Trebuchet24", size = 20, weight = 700})

local active, endTime, activatorName = false, 0, "Unknown"
local beepDuration, sirenLead = 10, 15
local nukeEnt = nil

local beepSound = Sound("buttons/blip1.wav")
local sirenPath = "ambient/alarms/siren.wav"
local explosionSound = Sound("ambient/explosions/explode_9.wav")
local sirenHandle = nil
local sirenTimer = nil

local function StartSiren()
    if sirenHandle then sirenHandle:Stop() end
    sirenHandle = CreateSound(LocalPlayer(), sirenPath)
    if sirenHandle then sirenHandle:PlayEx(1, 100) end
end

local function StopSiren()
    if sirenHandle then sirenHandle:Stop() sirenHandle = nil end
    if sirenTimer then timer.Remove(sirenTimer) sirenTimer = nil end
end

net.Receive("Nuke_Start", function()
    nukeEnt = net.ReadEntity()
    endTime = net.ReadFloat()
    activatorName = net.ReadString()
    beepDuration = net.ReadUInt(8)
    sirenLead = net.ReadUInt(8)
    active = true

    for i = 0, math.max(0, beepDuration - 1) do
        timer.Simple(i, function() if active then surface.PlaySound(beepSound) end end)
    end

    local untilDet = endTime - CurTime()
    if untilDet > sirenLead then
        sirenTimer = "RetrosoulNuke_Siren_" .. (IsValid(nukeEnt) and nukeEnt:EntIndex() or 0)
        timer.Create(sirenTimer, untilDet - sirenLead, 1, function()
            if active then StartSiren() end
        end)
    end
end)

net.Receive("Nuke_Stop", function()
    active = false
    StopSiren()
end)

net.Receive("Nuke_ExplodeStart", function()
    StopSiren()
    local flashTime = net.ReadInt(8)
    surface.PlaySound(explosionSound)
    local stopAt = CurTime() + flashTime
    hook.Add("RenderScreenspaceEffects", "RetrosoulNuke_Flash", function()
        local rem = math.max(0, stopAt - CurTime())
        if rem <= 0 then hook.Remove("RenderScreenspaceEffects", "RetrosoulNuke_Flash") return end
        local alpha = math.Clamp(255 * (rem / flashTime), 0, 255)
        surface.SetDrawColor(255,255,255,alpha)
        surface.DrawRect(0,0,ScrW(),ScrH())
    end)
end)

-- Bottom-center HUD
hook.Add("HUDPaint", "RetrosoulNuke_HUD", function()
    if not active or not IsValid(nukeEnt) then return end
    local rem = math.max(0, endTime - CurTime())
    local mins, secs = math.floor(rem / 60), math.floor(rem % 60)
    local dist = 0
    if IsValid(LocalPlayer()) and IsValid(nukeEnt) then
        dist = math.floor(LocalPlayer():GetPos():Distance(nukeEnt:GetPos()))
    end
    local w,h = 540, 90
    local x,y = (ScrW()-w)/2, ScrH()-h-40
    local urgent = rem <= 30
    draw.RoundedBox(10, x, y, w, h, Color(0,0,0,160))
    if urgent then
        local pulse = 80 + 60 * math.abs(math.sin(CurTime() * 6))
        surface.SetDrawColor(255,0,0,pulse)
        surface.DrawOutlinedRect(x,y,w,h,3)
    end
    draw.SimpleText("WARHEAD DETONATION IN: " .. string.format("%02d:%02d", mins, secs), "RetrosoulNuke_Big", ScrW()/2, y+8, Color(255,60,60), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    draw.SimpleText("Armed by: " .. activatorName, "RetrosoulNuke_Small", ScrW()/2, y+46, Color(255,200,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    draw.SimpleText("Distance: " .. dist .. " units", "RetrosoulNuke_Small", ScrW()/2, y+66, Color(255,200,200), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end)

-- 2D HUD Marker (through-walls indicator)
do
    local function DrawWarheadMarker()
        if not active or not IsValid(nukeEnt) then return end
        local lp = LocalPlayer()
        if not IsValid(lp) then return end

        local scrW, scrH = ScrW(), ScrH()
        local pos = nukeEnt:WorldSpaceCenter() + Vector(0, 0, 20)
        local scr = pos:ToScreen()
        local x, y = scr.x, scr.y
        local onScreen = scr.visible and x >= 0 and x <= scrW and y >= 0 and y <= scrH

        local dist = math.floor(lp:GetPos():Distance(nukeEnt:GetPos()))
        local colMain = Color(255, 60, 60)
        local colText = Color(255, 200, 200)
        local bg = Color(0, 0, 0, 160)

        if onScreen then
            local boxW, boxH = 160, 44
            local bx = math.Clamp(x, boxW * 0.5 + 8, scrW - boxW * 0.5 - 8)
            local by = math.Clamp(y, 28, scrH - 28)
            draw.RoundedBox(8, bx - boxW / 2, by - boxH / 2, boxW, boxH, bg)
            draw.SimpleText("WARHEAD", "RetrosoulNuke_Small", bx, by - 8, colMain, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText(dist .. " units", "RetrosoulNuke_Small", bx, by + 10, colText, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        else
            local cx, cy = scrW / 2, scrH / 2
            local ang = math.atan2(y - cy, x - cx)
            local radius = math.min(cx, cy) - 24
            local ex = cx + math.cos(ang) * radius
            local ey = cy + math.sin(ang) * radius

            surface.SetDrawColor(255, 60, 60, 230)
            draw.NoTexture()
            local size = 12
            local points = { 
                { x = ex + math.cos(ang) * (size + 4), y = ey + math.sin(ang) * (size + 4) },
                { x = ex + math.cos(ang + 2.5) * size, y = ey + math.sin(ang + 2.5) * size },
                { x = ex + math.cos(ang - 2.5) * size, y = ey + math.sin(ang - 2.5) * size }
            }
            surface.DrawPoly(points)

            local boxW, boxH = 80, 24
            draw.RoundedBox(6, ex - boxW / 2, ey + 14, boxW, boxH, bg)
            draw.SimpleText(dist .. "u", "RetrosoulNuke_Small", ex, ey + 26, colText, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
    hook.Add("HUDPaint", "RetrosoulNuke_Marker", DrawWarheadMarker)
end
