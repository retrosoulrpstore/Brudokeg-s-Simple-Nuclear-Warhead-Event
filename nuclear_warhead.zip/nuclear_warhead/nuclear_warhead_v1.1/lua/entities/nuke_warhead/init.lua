AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

util.AddNetworkString("Nuke_Start")
util.AddNetworkString("Nuke_Stop")
util.AddNetworkString("Nuke_ExplodeStart")
util.AddNetworkString("Nuke_UpdateBeep")

NUKE_CONFIG = {
    Price = 5000000,
    Reward = 5000000,
    CountdownTime = 300,
    CooldownTime = 1800,
    BeepDuration = 10,
    SirenTime = 30,
    Model = "models/radioisotope-powergenerator/radioisotope-powergenerator.mdl"
}

if SERVER then SetGlobalFloat("Nuke_NextAvailable", 0) end

function ENT:Initialize()
    self:SetModel(NUKE_CONFIG.Model)
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    local phys = self:GetPhysicsObject()
    if IsValid(phys) then phys:Wake() end
    self.Active = false
    self.Activator = nil
    self.StartTime = nil
    self.EndTime = nil
end

hook.Add("PlayerSpawnedSENT", "RetrosoulWarhead_AssignBuyer", function(ply, ent)
    if IsValid(ent) and ent:GetClass() == "nuke_warhead" then ent.Buyer = ply end
end)

local function broadcastStart(self)
    net.Start("Nuke_Start")
    net.WriteEntity(self)
    net.WriteFloat(self.EndTime)
    net.WriteString(IsValid(self.Activator) and self.Activator:Nick() or "Unknown")
    net.WriteUInt(NUKE_CONFIG.BeepDuration, 8)
    net.WriteUInt(NUKE_CONFIG.SirenTime, 8)
    net.Broadcast()
end

function ENT:Use(activator)
    if not IsValid(activator) or not activator:IsPlayer() then return end
    local now = CurTime()
    local nextAvail = GetGlobalFloat("Nuke_NextAvailable", 0)
    if now < nextAvail then
        local remaining = math.ceil(nextAvail - now)
        local mins = math.floor(remaining / 60)
        local secs = remaining % 60
        if DarkRP and DarkRP.notify then
            DarkRP.notify(activator, 1, 6, "[WARHEAD] Recharging. Wait " .. mins .. "m " .. secs .. "s")
        else
            activator:ChatPrint("[WARHEAD] Recharging. Wait " .. mins .. "m " .. secs .. "s")
        end
        return
    end

    if not self.Active then
        self.Active = true
        self.Activator = activator
        self.StartTime = CurTime()
        self.EndTime = self.StartTime + NUKE_CONFIG.CountdownTime
        SetGlobalFloat("Nuke_NextAvailable", CurTime() + NUKE_CONFIG.CooldownTime)

        local timerID = "RetrosoulWarhead_Count_" .. self:EntIndex()
        timer.Create(timerID, 1, NUKE_CONFIG.CountdownTime, function()
            if not IsValid(self) then timer.Remove(timerID) return end
            net.Start("Nuke_UpdateBeep")
            net.WriteInt(math.max(0, math.ceil(self.EndTime - CurTime())), 16)
            net.Broadcast()
        end)

        local explodeTimer = "RetrosoulWarhead_Expl_" .. self:EntIndex()
        timer.Create(explodeTimer, NUKE_CONFIG.CountdownTime, 1, function()
            if not IsValid(self) then return end
            net.Start("Nuke_ExplodeStart")
            net.WriteInt(3, 8)
            net.Broadcast()
            util.ScreenShake(self:GetPos(), 25, 200, 3, 50000)

            timer.Simple(3, function()
                if not IsValid(self) then return end
                local attacker = IsValid(self.Activator) and self.Activator or self
                for _, ply in ipairs(player.GetAll()) do
                    if IsValid(ply) and ply:Alive() then
                        local dmg = DamageInfo()
                        dmg:SetDamage(1000)
                        dmg:SetAttacker(attacker)
                        dmg:SetInflictor(self)
                        dmg:SetDamageType(DMG_BLAST)
                        dmg:SetDamageForce((ply:GetPos() - self:GetPos()):GetNormalized() * 50000)
                        ply:TakeDamageInfo(dmg)
                    end
                end

                local buyer = IsValid(self.Buyer) and self.Buyer or attacker
                if IsValid(buyer) and buyer.addMoney then buyer:addMoney(NUKE_CONFIG.Reward) end
                for _, p in ipairs(player.GetAll()) do
                    p:ChatPrint("[WARHEAD DETONATED] " .. (IsValid(attacker) and attacker:Nick() or "Unknown") .. " has razed the city!")
                end

                self.Active = false
                self.Activator = nil
                self.StartTime = nil
                self.EndTime = nil
                net.Start("Nuke_Stop") net.Broadcast()
                self:Remove()
            end)
        end)

        broadcastStart(self)
        activator:ChatPrint("[WARHEAD] Launch sequence initiated. Countdown started.")
        for _, p in ipairs(player.GetAll()) do
            if p ~= activator then p:ChatPrint("[WARHEAD ALERT] " .. activator:Nick() .. " has armed the Nuclear Warhead!") end
        end
        return
    end

    if self.Active and activator ~= self.Activator then
        timer.Remove("RetrosoulWarhead_Count_" .. self:EntIndex())
        timer.Remove("RetrosoulWarhead_Expl_" .. self:EntIndex())

        if activator.addMoney then activator:addMoney(NUKE_CONFIG.Reward) end
        if DarkRP and DarkRP.notify then
            DarkRP.notify(activator, 0, 8, "You deactivated the warhead and received $" .. string.Comma(NUKE_CONFIG.Reward) .. ".")
        else
            activator:ChatPrint("You deactivated the warhead and received $" .. NUKE_CONFIG.Reward .. ".")
        end
        for _, p in ipairs(player.GetAll()) do p:ChatPrint("[WARHEAD] Launch sequence deactivated by " .. activator:Nick() .. ". Reward granted.") end
        net.Start("Nuke_Stop") net.Broadcast()

        self.Active = false
        self.Activator = nil
        self.StartTime = nil
        self.EndTime = nil
        self:Remove()
        return
    end

    if activator == self.Activator then
        if DarkRP and DarkRP.notify then
            DarkRP.notify(activator, 1, 6, "You cannot deactivate a launch you initiated.")
        else
            activator:ChatPrint("You cannot deactivate a launch you initiated.")
        end
    end
end

function ENT:OnRemove()
    timer.Remove("RetrosoulWarhead_Count_" .. self:EntIndex())
    timer.Remove("RetrosoulWarhead_Expl_" .. self:EntIndex())
end