DarkRP.createCategory {
    name = "Event",
    categorises = "entities",
    startExpanded = true,
    color = Color(255, 0, 0),
    sortOrder = 199,
}

DarkRP.createEntity("Nuclear Warhead", {
    ent = "nuke_warhead",
    model = "models/radioisotope-powergenerator/radioisotope-powergenerator.mdl",
    price = 5000000,
    max = 1,
    cmd = "buywarhead",
    category = "Event",
    })